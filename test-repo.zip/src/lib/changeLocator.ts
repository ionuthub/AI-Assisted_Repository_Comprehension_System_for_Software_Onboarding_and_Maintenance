import { searchRepository, SearchIndex, tokenize } from "./semanticSearch";
import { FileAnalysisResult } from "./staticAnalysis";
import { ProjectFile } from "@/types/project";

export interface ChangeLocationRecommendation {
  path: string;
  confidence: "High" | "Medium" | "Low";
  confidenceScore: number;
  reason: string;
  affectedFiles: string[]; // Files that import this file (downstream impact)
  dependencies: string[];   // Files imported by this file (upstream dependencies)
}

/**
 * Recommends where to perform code changes based on a query.
 * Cross-references search indices and static dependency maps to calculate impact boundaries.
 */
export const locateChangeScope = (
  query: string,
  index: SearchIndex,
  files: ProjectFile[],
  staticAnalyses: Record<string, FileAnalysisResult>
): ChangeLocationRecommendation[] => {
  const searchResults = searchRepository(query, index, files, 4);
  const recommendations: ChangeLocationRecommendation[] = [];

  const queryTokens = tokenize(query);

  searchResults.forEach((res) => {
    const fileObj = files.find((f) => f.path === res.path);
    const fileContent = fileObj?.content || "";
    
    // 1. Calculate confidence tier
    let confidence: "High" | "Medium" | "Low" = "Low";
    if (res.score > 0.4) {
      confidence = "High";
    } else if (res.score > 0.15) {
      confidence = "Medium";
    }

    // 2. Extract matched keywords for explanation reasoning
    const fileTextSample = `${res.path.replace(/\//g, " ")} ${fileContent.slice(0, 1000)}`;
    const fileTokens = tokenize(fileTextSample);
    const overlappingTerms = queryTokens.filter(t => fileTokens.includes(t));
    const uniqueTerms = Array.from(new Set(overlappingTerms));
    
    const matchedKeywordString = uniqueTerms.length > 0 
      ? `Identified matching tokens: "${uniqueTerms.join(", ")}"`
      : `High mathematical cosine similarity in file structures`;

    // 3. Extract dependencies from static analysis
    const fileAnalysis = staticAnalyses[res.path];
    const affectedFiles = fileAnalysis?.usedBy || [];
    const dependencies = fileAnalysis?.imports
      .map(imp => imp.resolvedPath)
      .filter((p): p is string => p !== null) || [];

    // 4. Build custom educational reasoning text
    let categoryReason = "";
    if (res.path.includes("validation") || fileContent.includes("validate") || fileContent.includes("regex")) {
      categoryReason = "It appears to validate business schemas, formats, or input restrictions.";
    } else if (res.path.includes("auth") || res.path.includes("login") || fileContent.includes("token")) {
      categoryReason = "It handles security verification, session creation, or authorization credentials.";
    } else if (res.path.includes("css") || res.path.includes("style") || fileContent.includes("className")) {
      categoryReason = "It contains layouts, CSS styles, or Tailwind markup determining appearance.";
    } else if (res.path.includes("api") || fileContent.includes("endpoint") || fileContent.includes("Request")) {
      categoryReason = "It serves server-side API routing logic or handles backend requests.";
    } else {
      categoryReason = "Contains core definitions relating to your modification prompt.";
    }

    const reason = `${matchedKeywordString}. ${categoryReason} Making changes here may affect visual rendering or data logic.`;

    recommendations.push({
      path: res.path,
      confidence,
      confidenceScore: res.score,
      reason,
      affectedFiles,
      dependencies
    });
  });

  return recommendations;
};
