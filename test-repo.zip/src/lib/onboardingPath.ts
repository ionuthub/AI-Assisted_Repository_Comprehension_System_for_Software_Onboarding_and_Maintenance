import { ProjectFile } from "@/types/project";

export interface OnboardingStep {
  pillar: number;
  title: string;
  goal: string;
  description: string;
  files: string[];
}

const PILLAR_CONFIGS: {
  pillar: number;
  title: string;
  goal: string;
  description: string;
  matchPattern: RegExp;
  excludePatterns?: RegExp[];
}[] = [
  {
    pillar: 1,
    title: "Project Configuration & Entry Points",
    goal: "Understand the environment, settings, and main boots.",
    description: "Start here to understand the metadata. This stage covers configuration files and main code entry portals.",
    matchPattern: /(package\.json|tsconfig\.json|vite\.config\.(ts|js)|index\.html|readme\.md|requirements\.txt|settings\.py|setup\.py)$/i
  },
  {
    pillar: 2,
    title: "Application Routing",
    goal: "Learn how the application navigates pages and routes incoming requests.",
    description: "Inspect routing configurations to understand how pages load and how user interactions are directed.",
    matchPattern: /(route|routing|router|app-routing|navigation|link|url|app\.(tsx|jsx|ts|js)|main\.(tsx|ts|jsx|js))$/i,
    excludePatterns: [/node_modules/i, /api/i]
  },
  {
    pillar: 3,
    title: "Authentication & User Management",
    goal: "Review login validation, sessions, authorization scopes, and permissions.",
    description: "Explore the security gate. Find how user profiles are handled, how credentials validate, and how roles are checked.",
    matchPattern: /(auth|login|register|signup|signin|signout|oauth|token|jwt|session|permission|role|user)/i,
    excludePatterns: [/node_modules/i]
  },
  {
    pillar: 4,
    title: "Database & Storage Layer",
    goal: "Inspect database schemas, ORM configurations, and migrations.",
    description: "This handles application storage and tables. Check models and migrations to see the core data models.",
    matchPattern: /(db|database|schema|model|migration|prisma|entity|sql|postgres|sqlite|mongodb|redis)/i,
    excludePatterns: [/node_modules/i, /components/i, /pages/i]
  },
  {
    pillar: 5,
    title: "UI Components & Layouts",
    goal: "Understand the visual building blocks and interactive page designs.",
    description: "Review UI templates, page layouts, styles, and themes that determine the frontend layout.",
    matchPattern: /(components|pages|views|layouts|assets|css|style|tailwind)/i,
    excludePatterns: [/node_modules/i, /api/i, /auth/i]
  },
  {
    pillar: 6,
    title: "API Backend Routes & Business Logic",
    goal: "Trace server-side endpoints, controllers, and database handlers.",
    description: "Inspect the backend routes that receive frontend requests, validate payloads, and write data.",
    matchPattern: /(api|server|routes|controllers|handlers|services)/i,
    excludePatterns: [/node_modules/i, /components/i, /ui/i]
  },
  {
    pillar: 7,
    title: "Testing, Linting, & Deployment Setup",
    goal: "Explore code checks, CI/CD scripts, and containers.",
    description: "See how automated tests validate code quality and how the container runs in production.",
    matchPattern: /(test|spec|vitest|playwright|jest|docker|dockerfile|yml|yaml|eslint|prettier|deploy)/i,
    excludePatterns: [/node_modules/i, /package\.json/i]
  }
];

/**
 * Categorizes project files into a 7-step onboarding path based on path signatures.
 */
export const generateOnboardingPath = (files: ProjectFile[]): OnboardingStep[] => {
  const steps: OnboardingStep[] = [];

  PILLAR_CONFIGS.forEach((config) => {
    const matchedFiles: string[] = [];

    files.forEach((file) => {
      const normalizedPath = file.path.replace(/\\/g, "/");

      // Check if match pattern fits
      const isMatch = config.matchPattern.test(normalizedPath);
      
      // Check if any exclude patterns fit
      const isExcluded = config.excludePatterns?.some((pattern) =>
        pattern.test(normalizedPath)
      );

      if (isMatch && !isExcluded) {
        matchedFiles.push(file.path);
      }
    });

    steps.push({
      pillar: config.pillar,
      title: `${config.pillar}. ${config.title}`,
      goal: config.goal,
      description: config.description,
      // Limit to max 10 files per category to keep it digestible, sorting by path length (shallower paths first)
      files: matchedFiles
        .sort((a, b) => a.split("/").length - b.split("/").length || a.localeCompare(b))
        .slice(0, 10)
    });
  });

  return steps;
};
